package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesFtpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesFtpApplication.class, args);
	}
}
