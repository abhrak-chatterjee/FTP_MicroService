package com.capgemini;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class FTPController
{
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String remove()
	{
		String baseUrl="http://localhost:9080/delete";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String>response=null;
		try
		{
			response=restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders1(), String.class);
		}
		catch(Exception ex)
		{
			System.out.println(response.getBody());
		}
		System.out.println(response.getBody());
		return response.getBody();
	}
	private static HttpEntity<?>getHeaders1() throws IOException
	{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	@RequestMapping(value="/move", method=RequestMethod.GET)
	public String cut()
	{
		String baseUrl="http://localhost:9080/move";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String>response=null;
		try
		{
			response=restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders2(), String.class);
		}
		catch(Exception ex)
		{
			System.out.println(response.getBody());
		}
		System.out.println(response.getBody());
		return response.getBody();
	}
	private static HttpEntity<?>getHeaders2() throws IOException
	{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	@RequestMapping(value="/copy", method=RequestMethod.GET)
	public String getCopy()
	{
		String baseUrl="http://localhost:9080/copy";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String>response=null;
		try
		{
			response=restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders3(), String.class);
		}
		catch(Exception ex)
		{
			System.out.println(response.getBody());
		}
		System.out.println(response.getBody());
		return response.getBody();
	}
	private static HttpEntity<?>getHeaders3() throws IOException
	{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	@RequestMapping(value="/update", method=RequestMethod.GET)
	public String getUpdate()
	{
		String baseUrl="http://localhost:9080/update";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String>response=null;
		try
		{
			response=restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders4(), String.class);
		}
		catch(Exception ex)
		{
			System.out.println(response.getBody());
		}
		System.out.println(response.getBody());
		return response.getBody();
	}
	private static HttpEntity<?>getHeaders4() throws IOException
	{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}
