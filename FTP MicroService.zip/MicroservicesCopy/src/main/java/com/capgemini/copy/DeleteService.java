package com.capgemini.copy;

import java.io.File;
import java.io.IOException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeleteService 
{	
	@RequestMapping(value="/delete")
	public String delfile() throws IOException
	{
		 File file = new File("D:\\Users\\abchatte\\fu\\b.txt");
         
	        if(file.delete())
	        {
	            System.out.println("File deleted successfully");
	        }
	        else
	        {
	            System.out.println("Failed to delete the file");
	        }
		         return "file deleted successfully";
	}

}
