package com.capgemini.copy;
import java.io.*;
import java.nio.file.*;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class ServiceMove {
	
	@RequestMapping(value="/move")
	public String movefile() throws IOException
	{
		Path temp = Files.move
		        (Paths.get("C:\\Users\\abchatte\\fu\\b.txt"), 
		        Paths.get("D:\\Users\\abchatte\\fu\\a.txt"));
		 
		        if(temp != null)
		        {
		            System.out.println("File renamed and moved successfully");
		        }
		        else
		        {
		            System.out.println("Failed to move the file");
		        }
		         return "file transfered successfully";
	}

}
